﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace server_control
{
    public partial class WebFor22 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            //100,30 | 105,105
            if ((e.X >= 1 && e.X <= 1) &&
    (e.Y >= 273) && (e.Y <= 0)) {
                Label1.Text = "You cliked the peson";
                    }
            else
                Label1.Text = "You cliked out";
                }
    }
}

