﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Index
{
    public partial class Index1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/index2.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Server.Transfer("~/index2.aspx");
        }
    }
}

/*add 2 web forms
 drop the hyper link and change the property of hyperlink navigate url =index2.aspx
 drop link button and change the postback url = index.aspx
 drop button in btnclick respnse.redirect = index.aspx
 drop button in btnclick server transfer method*/
